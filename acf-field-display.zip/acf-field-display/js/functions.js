jQuery(document).ready(function($){
	if($('.tablesorter').length ){
		$('.tablesorter').tablesorter();
	}
});